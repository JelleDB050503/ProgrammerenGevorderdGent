﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisStatsBL
{
    public class Haven
    {
        public int Id { get; set; }
        public string Naam { get; set; }
        public string Locatie { get; set; }
        public int Capaciteit { get; set; }

        public Haven(string naam)
        {
           
            Naam = naam;  
            
            
        }

        public Haven() { }
    }
}
