﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisStatsBL.Exceptions;
using VisStatsBL.Interfaces;
using VisStatsBL.Model;

namespace VisStatsBL
{
    public class visStatsManager
    {
        private IFileProcessor fileProcessor;
        private IVisStatsRepository visStatsRepository;

        public visStatsManager(IFileProcessor fileProcessor, IVisStatsRepository visStatsRepository)
        {
            this.fileProcessor = fileProcessor;
            this.visStatsRepository = visStatsRepository;
        }

        public void UploadVissoorten(string fileName)
        {
            try 
            { 
            List<string> soorten = fileProcessor.LeesSoorten(fileName);
            List<Vissoort> vissoorten = MaakVissoorten(soorten);
            foreach(Vissoort vis in vissoorten)
            {
                if (!visStatsRepository.HeeftVissoort(vis))
                {
                    visStatsRepository.SchrijfSoort(vis);
                }
            }
           } catch (Exception ex) { }
        }

        private List<Vissoort> MaakVissoorten(List<string> soorten)
        {
            Dictionary<string, Vissoort> visSoorten = new();
            foreach(string soort in soorten)
            {
                if (!visSoorten.ContainsKey(soort))
                {
                    try { 
                    visSoorten.Add(soort, new Vissoort(soort));
                    }
                    catch (DomeinException)
                    { 
                        // do stuff feedback
                    }
                }
            }
            return visSoorten.Values.ToList();
        }
        public void UploadHavens(string fileName)
        {
            try
            {
                List<string> havens = fileProcessor.LeesHavens(fileName);
                List<Haven> havenLijst = MaakHavens(havens);

                foreach (Haven haven in havenLijst)
                {
                    if (!visStatsRepository.HeeftHaven(haven))
                    {
                        visStatsRepository.SchrijfHaven(haven);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log de fout of geef een relevante melding terug
                throw new Exception("Fout tijdens het uploaden van havens", ex);
            }
        }
        private List<Haven> MaakHavens(List<string> havens)
        {
            List<Haven> havenLijst = new();
            foreach (string havenNaam in havens)
            {
                try
                {
                    Haven haven = new Haven(havenNaam);
                    havenLijst.Add(haven);
                }
                catch (DomeinException ex)
                {
                    Console.WriteLine($"Fout bij het aanmaken van haven: {ex.Message}");
                }
            }
            return havenLijst;
        }
    }
}
