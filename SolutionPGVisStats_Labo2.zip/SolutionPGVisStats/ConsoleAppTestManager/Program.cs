﻿using VisStatsBL;
using VisStatsBL.Interfaces;
using VisStatsDL_File;
using VisStatsDL_SQL;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ConsoleAppTestManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            string conn = "Data Source=DESKTOP-LDV6028\\SQLEXPRESS;Initial Catalog=VisStats1F;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            string filePath = @"C:\Users\Gebruiker\gradprog\ProgrammerenGevorderdGent\SolutionPGVisStats\Data\vissoorten1.txt";
            IFileProcessor fp = new FileProcessor();
            IVisStatsRepository repo = new VisStatsRepository(conn);

            visStatsManager vm = new visStatsManager(fp, repo);
            vm.UploadVissoorten(filePath);
        }
    }
}
