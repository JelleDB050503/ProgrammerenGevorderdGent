﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VisStatsBL;
using VisStatsBL.Interfaces;
using VisStatsDL_File;
using VisStatsDL_SQL;

namespace VisStatsUI_DataUpload
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog();
        string conn = "Data Source=DESKTOP-LDV6028\\SQLEXPRESS;Initial Catalog=VisStats1F;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
        IFileProcessor fileProcessor;
        IVisStatsRepository visStatsRepository;
        visStatsManager visStatsManager;
        public MainWindow()
        {
            InitializeComponent();
            dialog.DefaultExt = ".txt";
            dialog.Filter = "Text documents (.txt)| *.txt";
            dialog.InitialDirectory = @"C:\Users\Gebruiker\gradprog\ProgrammerenGevorderdGent\SolutionPGVisStats\Data";
            dialog.Multiselect = true;
            fileProcessor = new FileProcessor();
            visStatsRepository = new VisStatsRepository(conn);
            visStatsManager = new visStatsManager(fileProcessor, visStatsRepository);
        }

        private void Button_Click_Vissoorten(object sender, RoutedEventArgs e)
        {
            bool? result = dialog.ShowDialog();
            if (result == true)
            {
                var filenames = dialog.FileNames;
                VissoortenFileListBox.ItemsSource = filenames;
                dialog.FileName = null;
            }
            else VissoortenFileListBox.ItemsSource=null;
        }

        private void Button_Click_UploadVissoorten(object sender, RoutedEventArgs e)
        {
            foreach (string fileName in VissoortenFileListBox.ItemsSource)
            {
                visStatsManager.UploadVissoorten(fileName);
            }
            MessageBox.Show("Upload klaar", "VisStats");
        }

        private void Button_Click_Havens(object sender, RoutedEventArgs e)
        {
            string naam = HavenNaamTextBox.Text;
            string locatie = HavenLocatieTextBox.Text;
            int capaciteit = int.Parse(HavenCapaciteitTextBox.Text);

            Haven nieuweHaven = new Haven
            {
                Naam = naam,
                Locatie = locatie,
                Capaciteit = capaciteit
            };

            if (!visStatsRepository.HeeftHaven(nieuweHaven))
            {
                visStatsRepository.SchrijfHaven(nieuweHaven);
                MessageBox.Show("Haven toegevoegd!");
            }
            else
            {
                MessageBox.Show("Haven bestaat al.");
            }
        }
    }
}